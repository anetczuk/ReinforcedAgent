# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/epsilon-greedy;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="84" HEIGHT="33" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$\epsilon-greedy$">|; 

$key = q/{0,1,ldots,19,20};MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="128" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$\{0, 1,\ldots,19,20\}$">|; 

1;

