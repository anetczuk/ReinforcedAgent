# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/sec:custom-flags/;
$ref_files{$key} = "$dir".q|JavaCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/mines-sample/;
$ref_files{$key} = "$dir".q|JavaCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:env/;
$ref_files{$key} = "$dir".q|JavaCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/sarsa-sample/;
$ref_files{$key} = "$dir".q|JavaCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:gotchas-shared-libs/;
$ref_files{$key} = "$dir".q|JavaCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/no-sockets/;
$ref_files{$key} = "$dir".q|JavaCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/all-one-class/;
$ref_files{$key} = "$dir".q|JavaCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/mines-sarsa-sample/;
$ref_files{$key} = "$dir".q|JavaCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:agent/;
$ref_files{$key} = "$dir".q|JavaCodec.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:structure-types/;
$ref_files{$key} = "$dir".q|JavaCodec.html|; 
$noresave{$key} = "$nosave";

1;

