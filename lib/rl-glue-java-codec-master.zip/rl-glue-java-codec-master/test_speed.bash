rl_glue &
java -Xmx128M -classpath products/JavaRLGlueCodec.jar org.rlcommunity.rlglue.codec.tests.Test_Speed_Environment &
java -Xmx128M -classpath products/JavaRLGlueCodec.jar org.rlcommunity.rlglue.codec.tests.Test_1_Agent &
java -Xmx128M -classpath products/JavaRLGlueCodec.jar org.rlcommunity.rlglue.codec.tests.Test_Speed_Experiment
